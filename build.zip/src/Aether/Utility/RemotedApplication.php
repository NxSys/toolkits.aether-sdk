<?php


class RemotedApplication
{
	public function setAcnEndpoint()
	{
		# code...
	}
	public function loginAcn()
	{
		# code...
	}

	public function getAvailableCommands()
	{
		# code...
	}

	public function sendComand()
	{
		# code...
	}
}